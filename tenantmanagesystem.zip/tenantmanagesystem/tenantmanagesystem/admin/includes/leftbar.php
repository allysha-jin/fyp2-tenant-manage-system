	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i>Room Types</a>
<ul>
<li><a href="create-roomtype.php">Create Room Type</a></li>
<li><a href="manage-roomtype.php">Manage Room Type</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-car"></i> Rooms</a>
					<ul>
						<li><a href="post-room.php">Post a Room</a></li>
						<li><a href="manage-rooms.php">Manage Rooms</a></li>
					</ul>
				</li>

<li><a href="#"><i class="fa fa-sitemap"></i> Bookings</a>
					<ul>
						<li><a href="new-bookings.php">New</a></li>
						<li><a href="confirmed-bookings.php">Confirmed</a></li>
						<li><a href="canceled-bookings.php">Canceled</a></li>
					</ul>
				</li>

		

				<li><a href="testimonials.php"><i class="fa fa-table"></i> Manage Testimonials</a></li>
				<li><a href="manage-contactusquery.php"><i class="fa fa-desktop"></i> Manage Contact Us Query</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i> Reg Tenants</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Manage Subscribers</a></li>

			</ul>
		</nav>