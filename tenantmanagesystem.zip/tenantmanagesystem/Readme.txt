How to run Project
1. Download and Unzip the file on your local system copy tenantmanagesystem .
2. Put carrental folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration

Open phpmyadmin
Create Database tenantmanagesystem
Import database tenantmanagesystem.sql (available SQL File Folder inside zip package)

For User
Open Your browser put inside browser “http://localhost/tenantmanagesystem”
Login Details for user:
Username : test@gmail.com
Password: Test@123

For Admin Panel
Open Your browser put inside browser “http://localhost/tenantmanagesystem/admin”
Login Details for admin :
Username: admin
Password: admin12345